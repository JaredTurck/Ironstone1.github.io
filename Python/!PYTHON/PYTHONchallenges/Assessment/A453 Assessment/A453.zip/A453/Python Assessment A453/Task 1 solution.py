def CalcCheckDigit(code):
    code = list(code)
    for i in range(0,len(code)):
        if i % 2:
            code[i] = int(code[i])*3
        else:
            code[i] = int(code[i])*1
    checkDigit = (sum(code) % 10)
    return checkDigit
def userInput():
    user = "invalid"
    while not len(user) == 7 and user.isdigit():
        user = input("Enter 7 digit code: ")
        if not len(user) == 7 and user.isdigit():
            print("Incorrect Input!")
        return user
menu = "invalid"
while not menu in ["1","2"]:
    menu = input("""Choose option bellow: \n1) calculate checkDigit
2) Check Validit of CheckDigit \n>>> """)
    if menu not in ["1","2"]:
        print("incorrect Input!")
if menu == "1":
    code = userInput()
    checkDigit = CalcCheckDigit(code)
    print("GTIN-8:",code,checkDigit)
elif menu == "2":
    code = userInput()
    checkDigit = CalcCheckDigit(code)
    if checkDigit == code[:7]:
        print("VALID GTIN-8 CODE!")
    else:
        print("INVALID GTIN-8 CODE!")
